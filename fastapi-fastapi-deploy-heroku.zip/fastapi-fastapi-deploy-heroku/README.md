# Deploying FastAPI app to Heroku

FastAPI Tutorials

A Simple API written using FastAPI framework, a python based framework to build production grade REST APIs.

The Procfile has the command to support the deployment of this Simple API to Heroku.


| Code 💻 | Video 📺 | Article 📝 |
|----------|-------------|------|
| [Deploying fastapi app to Heroku](https://github.com/windson/fastapi/tree/fastapi-deploy-heroku) | [Deploy FastAPI on Heroku in just 6 minutes](http://bit.ly/3aO1g35) | [Create and Deploy FastAPI app to Heroku](http://bit.ly/2RD68jM) |
